const PRODUCTS=[
{id:1,name:"Regedit Basic",price:29000,desc:"Gói cơ bản dành cho người dùng mới.",tag:"BASIC",image:"assets/products/regedit-basic.jpeg"},
{id:2,name:"Regedit Pro",price:59000,desc:"Gói nâng cao, giao diện và hướng dẫn đầy đủ.",tag:"POPULAR",image:"assets/products/regedit-pro.jpeg"},
{id:3,name:"Regedit Premium",price:99000,desc:"Gói Premium kèm hỗ trợ cài đặt theo hướng dẫn.",tag:"PREMIUM",image:"assets/products/regedit-premium.jpeg"}
];
// Optional backend endpoint. Leave empty to use the Techcombank QR payment flow below.
const PAYMENT_API_URL = '';
let cart=[];
// Cart is intentionally in-memory only: refreshing the page starts with an empty cart.

const money=n=>new Intl.NumberFormat('vi-VN').format(n)+'đ';
const grid=document.querySelector('#productsGrid');
grid.innerHTML=PRODUCTS.map(p=>`<article class="card"><img class="product-demo" src="${p.image}" alt="Demo ${p.name}" loading="lazy"><span class="tag">${p.tag}</span><h3>${p.name}</h3><p>${p.desc}</p><div class="price">${money(p.price)}</div><button class="buy" onclick="add(${p.id})">THÊM VÀO GIỎ</button></article>`).join('');
function add(id){const product=PRODUCTS.find(p=>p.id===id);if(!product)return;cart.push(product);update();openCart()}
function update(){document.querySelector('#cartCount').textContent=cart.length;document.querySelector('#cartItems').innerHTML=cart.length?cart.map((p,i)=>`<div class="cartrow"><span>${p.name}</span><b>${money(p.price)}</b></div>`).join(''):'<p>Giỏ hàng đang trống.</p>';document.querySelector('#total').textContent=money(cart.reduce((s,p)=>s+p.price,0))}
function openCart(){document.querySelector('#modal').classList.remove('hidden');update()}
document.querySelector('#cartBtn').onclick=openCart;document.querySelector('#close').onclick=()=>document.querySelector('#modal').classList.add('hidden');
document.querySelector('#order').onclick=async()=>{
 if(!cart.length)return alert('Vui lòng chọn sản phẩm.');
 const name=document.querySelector('#customer').value.trim(),contact=document.querySelector('#contact').value.trim();
 if(!name||!contact)return alert('Vui lòng nhập thông tin liên hệ.');
 const total=cart.reduce((sum,p)=>sum+p.price,0);
 const items=cart.map(p=>({id:p.id,name:p.name,price:p.price}));
 const result=document.querySelector('#result');
 const paymentBox=document.querySelector('#paymentBox');
 const paymentInfo=document.querySelector('#paymentInfo');
 const confirmPayment=document.querySelector('#confirmPayment');
 const btn=document.querySelector('#order');
 btn.disabled=true;btn.textContent='ĐANG TẠO ĐƠN...';
 try{
   let code='DB-'+Date.now().toString().slice(-8);
   let paymentUrl='';

   // Nếu đã cấu hình backend thì gọi API. Nếu chưa có, dùng QR Techcombank trực tiếp.
   if(PAYMENT_API_URL){
     const res=await fetch(PAYMENT_API_URL,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({customer:{name,contact},items,total,currency:'VND'})});
     if(!res.ok)throw new Error('HTTP '+res.status);
     const data=await res.json();
     code=data.order_code||data.orderId||code;
     paymentUrl=data.payment_url||data.checkout_url||data.url||'';
   }

   paymentBox.classList.remove('hidden');
   paymentInfo.innerHTML=`<div class="payment-info"><b>Mã đơn:</b> ${code}<br><b>Số tiền:</b> ${money(total)}<br><b>Nội dung:</b> ${code}</div>`;
   confirmPayment.classList.remove('hidden');
   confirmPayment.disabled=false;
   confirmPayment.textContent='XÁC NHẬN ĐÃ THANH TOÁN';
   confirmPayment.dataset.orderCode=code;
   result.innerHTML=paymentUrl
     ? `<br><a href="${paymentUrl}" target="_blank" rel="noopener" style="color:#00ffb3;font-weight:800">MỞ TRANG THANH TOÁN →</a>`
     : '<span style="color:#00ffb3">Quét QR để thanh toán. Sau khi chuyển khoản, gửi mã đơn cho shop để đối soát.</span>';
   cart=[];update();
 }catch(e){
   result.innerHTML='<span style="color:#ff6b6b">API thanh toán đang không khả dụng. Đã chuyển sang thanh toán bằng QR để bạn vẫn có thể tạo đơn.</span>';
   console.error('Payment API error:',e);
 }finally{btn.disabled=false;btn.textContent='TẠO ĐƠN';}
};
confirmPayment.onclick=()=>{
  const code=confirmPayment.dataset.orderCode||'';
  confirmPayment.disabled=true;
  confirmPayment.textContent='ĐÃ GỬI XÁC NHẬN';
  result.innerHTML=`<span style="color:#00ffb3">Đã ghi nhận yêu cầu xác nhận cho đơn <b>${code}</b>. Shop sẽ đối soát giao dịch trước khi giao sản phẩm.</span>`;
};
update();
